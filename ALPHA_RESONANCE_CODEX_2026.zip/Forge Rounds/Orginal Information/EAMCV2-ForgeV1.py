# Filename: PantheonForge.py
# The definitive, parallelized Curriculum Engine to forge the E2 Pantheon.

import json
import torch
import torch.nn as nn
import torch.optim as optim
import numpy as np
import os
import time
from multiprocessing import Pool, cpu_count, Manager

# --- (SpecialistModel is unchanged and stable) ---
class SpecialistModel(nn.Module):
    def __init__(self, D_in, N_in):
        super(SpecialistModel, self).__init__()
        self.D = D_in
        self.N = N_in
        self.feature_extractor = nn.Sequential(nn.Linear(self.D, 96), nn.Sigmoid(), nn.LayerNorm(96), nn.Linear(96, 48), nn.Sigmoid())
        self.scoring_head = nn.Linear(48, 1)
        self.project_to_latent = nn.Linear(48, 16)
        self.project_from_latent = nn.Linear(16, 48)
    def forward(self, x):
        features = self.feature_extractor(x)
        scores = self.scoring_head(features).squeeze(-1)
        return scores

# --- (Data Generators are verified and stable) ---
def generate_euclidean_batch(batch_size, D, N):
    points = torch.randn(batch_size, N, D)
    distances = torch.norm(points, dim=2)
    labels = torch.argmin(distances, dim=1)
    return points, labels

def generate_curved_space_batch(batch_size, D, N, space_curvature=0.5):
    positions = torch.randn(batch_size, N, D) * 2
    base_metric = torch.eye(D).unsqueeze(0).repeat(batch_size, 1, 1)
    noise = torch.randn(batch_size, D, D) * space_curvature
    symmetric_noise = (noise + noise.transpose(1, 2)) / 2
    curvature_matrix = base_metric + symmetric_noise
    curved_positions = torch.bmm(positions, curvature_matrix)
    p_i = curved_positions.unsqueeze(2); p_j = curved_positions.unsqueeze(1); delta = p_i - p_j
    batch_size_val, N_val, _, D_val = delta.shape
    delta_reshaped = delta.reshape(batch_size_val * N_val * N_val, 1, D_val)
    curvature_matrix_expanded = curvature_matrix.repeat_interleave(N_val * N_val, dim=0)
    delta_transformed = torch.bmm(delta_reshaped, curvature_matrix_expanded).reshape(batch_size_val, N_val, N_val, D_val)
    dist_sq = torch.sum(delta * delta_transformed, dim=-1)
    dist_sq = dist_sq + torch.eye(N) * 1e9
    min_distances_per_sphere = torch.sqrt(torch.min(dist_sq, dim=2).values)
    labels = torch.argmax(min_distances_per_sphere, dim=1)
    centroid = torch.mean(curved_positions, dim=1, keepdim=True)
    final_input = curved_positions - centroid
    return final_input, labels

# --- The Worker Function for Parallel Training ---
def train_and_save_worker(args):
    D, N, num_epochs_l1, num_epochs_l2, batch_size, pantheon_dict, lock = args
    process_id = os.getpid()
    
    # --- SEMESTER 1: Freshman Year ---
    print(f"[{process_id}] Starting E1 training for {D}D Specialist...")
    model = SpecialistModel(D, N)
    optimizer = optim.Adam(model.parameters(), lr=0.001)
    criterion = nn.CrossEntropyLoss()
    for epoch in range(num_epochs_l1):
        inputs, labels = generate_euclidean_batch(batch_size, D, N)
        optimizer.zero_grad(); outputs = model(inputs); loss = criterion(outputs, labels)
        loss.backward(); optimizer.step()
    
    # Evaluate E1
    with torch.no_grad():
        test_inputs, test_labels = generate_euclidean_batch(1000, D, N)
        accuracy_l1 = (torch.max(model(test_inputs), 1)[1] == test_labels).sum().item() / 1000
    print(f"[{process_id}] E1 for {D}D complete. Accuracy: {accuracy_l1*100:.2f}%")

    if accuracy_l1 < 0.8:
        print(f"[{process_id}] WARNING: E1 training for {D}D failed. Aborting.")
        return

    # --- SEMESTER 2: Sophomore Year ---
    print(f"[{process_id}] Starting E2 training for {D}D Specialist...")
    for epoch in range(num_epochs_l2):
        inputs, labels = generate_curved_space_batch(batch_size, D, N)
        optimizer.zero_grad(); outputs = model(inputs); loss = criterion(outputs, labels)
        loss.backward(); optimizer.step()
        
    # Evaluate E2
    with torch.no_grad():
        test_inputs, test_labels = generate_curved_space_batch(1000, D, N)
        accuracy_l2 = (torch.max(model(test_inputs), 1)[1] == test_labels).sum().item() / 1000
    print(f"[{process_id}] E2 for {D}D complete. Accuracy: {accuracy_l2*100:.2f}%")

    # --- Prepare weights for saving ---
    state_dict = model.state_dict()
    weights_dict = {
        name: tensor.cpu().numpy().tolist()
        for name, tensor in state_dict.items()
    }
    
    # Restructure for our specific JSON format
    final_weights = {
        "feature_extractor": {
            "W": [weights_dict['feature_extractor.0.weight'], weights_dict['feature_extractor.3.weight']],
            "b": [weights_dict['feature_extractor.0.bias'], weights_dict['feature_extractor.3.bias']]
        },
        "scoring_head": {"W": [weights_dict['scoring_head.weight']], "b": [weights_dict['scoring_head.bias']]},
        "project_to_latent": {"W": [weights_dict['project_to_latent.weight']], "b": [weights_dict['project_to_latent.bias']]},
        "project_from_latent": {"W": [weights_dict['project_from_latent.weight']], "b": [weights_dict['project_from_latent.bias']]}
    }
    
    specialist_data = {
        "dimensionality": D,
        "accuracy": accuracy_l2,
        "weights": final_weights
    }
    
    # --- Safely write to the shared dictionary ---
    with lock:
        pantheon_dict[str(D)] = specialist_data
        print(f"[{process_id}] {D}D Specialist weights prepared for saving.")

# --- Main Execution Block ---
if __name__ == "__main__":
    start_time = time.time()
    
    # Use a Manager to create a shared dictionary and lock for safe parallel writing
    manager = Manager()
    pantheon_dict = manager.dict()
    lock = manager.Lock()
    
    # Training Parameters
    N_POINTS = 15
    EPOCHS_L1 = 150
    EPOCHS_L2 = 200
    BATCH_SIZE = 512
    DIMENSIONS_TO_TRAIN = list(range(3, 13)) # 3D to 12D

    # Prepare arguments for each parallel process
    tasks = [(D, N_POINTS, EPOCHS_L1, EPOCHS_L2, BATCH_SIZE, pantheon_dict, lock) for D in DIMENSIONS_TO_TRAIN]
    
    # Determine number of CPU cores to use
    num_cores = cpu_count()
    print(f"Found {num_cores} CPU cores. Starting parallel training...")

    # --- Unleash the Forge ---
    with Pool(processes=num_cores) as pool:
        pool.map(train_and_save_worker, tasks)
        
    print("\n--- All training processes complete. Consolidating Pantheon... ---")
    
    # Consolidate the final Pantheon file
    final_pantheon = {"latent_dim": 16, "pantheon": dict(pantheon_dict)}
    
    with open('EAMC_weights_v2.json', 'w') as f:
        json.dump(final_pantheon, f, indent=4)

    total_time = time.time() - start_time
    print(f"\n✅ New Pantheon forged and saved to EAMC_weights_v2.json in {total_time/60:.2f} minutes.")